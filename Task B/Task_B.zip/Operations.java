public enum Operations {
    OR,
    AND,
    IMPL,
    NOT,
    CONST
}
