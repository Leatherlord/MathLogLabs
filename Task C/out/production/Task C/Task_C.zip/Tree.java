public class Tree {
    private Tree left;
    private Tree right;
    private final String value;
    private final Operations operation;
    private boolean axiomOrHypothesis = false;
    private int howManyInversions = 0;
    private boolean parentheses = false;

    public void setParentheses(boolean parentheses) {
        this.parentheses = parentheses;
    }

    public Tree(Tree left, Tree right, String value, Operations operation) {
        this.left = left;
        this.right = right;
        this.value = value;
        this.operation = operation;
    }

    public int getHowManyInversions() {
        return howManyInversions;
    }

    public void setHowManyInversions(int howManyInversions) {
        this.howManyInversions = howManyInversions;
    }

    public boolean isAxiomOrHypothesis() {
        return axiomOrHypothesis;
    }

    public void setAxiomOrHypothesis(boolean axiomOrHypothesis) {
        this.axiomOrHypothesis = axiomOrHypothesis;
    }

    public Tree getLeft() {
        return left;
    }

    public Tree getRight() {
        return right;
    }

    public Operations getOperation() {
        return operation;
    }

    public String toTaskA() {
        StringBuilder string = new StringBuilder();
        if (operation != Operations.CONST) {
            for (int i = 0; i < howManyInversions; i++) {
                string.append("(!");
            }
//            string.append("(");
        }
        if (operation != Operations.CONST) {
            string.append("(");
        }
        switch (operation) {
            case OR:
                string.append("|,").append(left.toTaskA()).append(",").append(right.toTaskA());
                break;
            case AND:
                string.append("&,").append(left.toTaskA()).append(",").append(right.toTaskA());
                break;
            case IMPL:
                string.append("->,").append(left.toTaskA()).append(",").append(right.toTaskA());
                break;
            case CONST:
                    for (int i = 0; i < howManyInversions; i++) {
                        string.append("(!");
                    }
                    string.append(value);
                    for (int i = 0; i < howManyInversions; i++) {
                        string.append(")");
                    }
                break;
            default:
                string.append("????");
                break;
        }
//        if (operation != Operations.CONST) {
//            string.append(")");
//        }
        if (operation != Operations.CONST) {
            string.append(")");
        }
        if (operation != Operations.CONST) {
            for (int i = 0; i < howManyInversions; i++) {
                string.append(")");
            }
//            string.append("(");
        }
        return string.toString();
    }

    public String toString() {
        StringBuilder string = new StringBuilder();
        for (int i = 0; i < howManyInversions; i++) {
            string.append("!");
        }
        if (operation != Operations.CONST) {
            string.append("(");
        }
            switch (operation) {
                case OR:
                    string.append(left.toString()).append(" | ").append(right.toString());
                    break;
                case AND:
                    string.append(left.toString()).append(" & ").append(right.toString());
                    break;
                case IMPL:
                    string.append(left.toString()).append(" -> ").append(right.toString());
                    break;
                case CONST:
                    string.append(value);
                    break;
                default:
                    string.append("????");
                    break;
            }
        if (operation != Operations.CONST) {
            string.append(")");
        }
        return string.toString();
    }

    public boolean equalsSigned(Tree tree) {
        return this.equals(tree) &&
                howManyInversions == tree.getHowManyInversions();
    }


    public boolean equals(Tree tree) {
        if (tree == null) return false;

        if (left != null && right != null) {
            return tree.getLeft() != null &&
                    tree.getRight() != null &&
                    left.equalsSigned(tree.getLeft()) &&
                    right.equalsSigned(tree.getRight()) &&
                    value.equals(tree.value) &&
                    operation == tree.operation;
        } else if (left == null && right != null) {
            return tree.getLeft() == null &&
                    tree.getRight() != null &&
                    right.equalsSigned(tree.getRight()) &&
                    value.equals(tree.value) &&
                    operation == tree.operation;
        } else if (left != null) {
            return tree.getLeft() != null &&
                    left.equalsSigned(tree.getLeft()) &&
                    tree.getRight() == null &&
                    value.equals(tree.value) &&
                    operation == tree.operation;
        } else {
            return tree.getLeft() == null &&
                    tree.getRight() == null &&
                    value.equals(tree.value) &&
                    operation == tree.operation;
        }
    }

    public void normalize() {
        if ((operation == Operations.AND || operation == Operations.OR) && operation == right.operation && !right.parentheses) {
            Tree left = new Tree(this.left, right.left, "", operation);
            this.left = left;
            this.right = right.right;
            normalize();
        }
        if (operation == Operations.CONST) return;
        left.normalize();
        right.normalize();
    }
}
