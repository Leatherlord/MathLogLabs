import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        String string = scanner.nextLine();
//        Parser parser = new Parser();
//        Tree tree = parser.parse(string);
//        System.out.println(tree.toTaskA());

//        String first = "((!!A->!A)->(!!A->!!A)->!!!A)->((!A)->((!!A->!A)->(!!A->!!A)->!!!A))";
//        String second = "(A|B|C)";
//        String third = "(A|B)|C";
//        String fourth = "A|(B|C)";
//        Parser parser = new Parser();
//        Tree firstTree = parser.parse(first);
//        Tree secondTree = parser.parse(second);
//        Tree thirdTree = parser.parse(third);
//        Tree fourthTree = parser.parse(fourth);
//        System.out.println(firstTree);
//        System.out.println(secondTree);
//        System.out.println(thirdTree);
//        System.out.println(fourthTree);
//        System.out.println("------------------------------");
//        System.out.println(firstTree.equalsSigned(secondTree));
//        System.out.println(firstTree.equalsSigned(thirdTree));
//        System.out.println(firstTree.equalsSigned(fourthTree));
//        System.out.println(secondTree.equalsSigned(thirdTree));
//        System.out.println(secondTree.equalsSigned(fourthTree));
//        System.out.println(thirdTree.equalsSigned(fourthTree));

        Scanner scanner = new Scanner(System.in);
        String string = scanner.nextLine();
        string = string.replaceAll("\\s", "");
        String[] theorem = string.split("\\|-");
        String[] hypotheses = theorem[0].split(",");
        Parser parser = new Parser();
        ArrayList<Tree> hypoTrees = (ArrayList<Tree>) Arrays.stream(hypotheses).map(parser::parse).collect(Collectors.toList());
        Tree lastHypo = hypoTrees.get(hypoTrees.size() - 1);
        lastHypo.setParentheses(true);
        ArrayList<Tree> trees = new ArrayList<>();
        int i = 0;
        while (scanner.hasNextLine()) {
            string = scanner.nextLine();
            string = string.replaceAll("\\s", "");
            trees.add(i, parser.parse(string));
            i++;
        }
        LinkedList<Tree> newTreesNotFinal = new LinkedList<>();
        for (int j = 0; j < trees.size(); j++) {
            Tree newTree = new Tree(lastHypo, trees.get(j), "", Operations.IMPL);
            for (int k = 0; k < hypoTrees.size() - 1; k++) {
                if (newTree.getRight().equalsSigned(hypoTrees.get(k))) {
                    newTree.getRight().setAxiomOrHypothesis(true);
                }
            }
            newTreesNotFinal.addLast(newTree);
        }

        LinkedList<Tree> newTreesFinal = new LinkedList<>();
        for (Tree tree : newTreesNotFinal) {
            if (tree.getRight().isAxiomOrHypothesis()) {
                newTreesFinal.addLast(new Tree(tree.getRight(), tree, "", Operations.IMPL));
                newTreesFinal.addLast(tree.getRight());
                newTreesFinal.addLast(tree);
            } else if (tree.getRight().equalsSigned(tree.getLeft())) {
                Tree first = new Tree(tree.getRight(), tree, "", Operations.IMPL);
                first.getRight().setParentheses(true);
                newTreesFinal.addLast(first);
                Tree formAxiom2Tree = new Tree(newTreesFinal.getLast(),
                        new Tree(
                                new Tree(lastHypo,
                                        new Tree(tree, lastHypo, "", Operations.IMPL),
                                        "", Operations.IMPL),
                                tree, "", Operations.IMPL
                        ),
                        "", Operations.IMPL);
                formAxiom2Tree.getLeft().setParentheses(true);
                formAxiom2Tree.getLeft().getRight().setParentheses(true);
                formAxiom2Tree.getRight().getLeft().setParentheses(true);
                formAxiom2Tree.getRight().getRight().setParentheses(true);
                formAxiom2Tree.getRight().getLeft().getRight().getLeft().setParentheses(true);
                newTreesFinal.addLast(formAxiom2Tree);
                newTreesFinal.addLast(newTreesFinal.getLast().getRight());
                newTreesFinal.addLast(newTreesFinal.getLast().getLeft());
                newTreesFinal.addLast(tree);
            } else {
                boolean done = false;
                for (Tree ancestor : newTreesFinal) {
                    if (tree.getRight().equalsSigned(ancestor.getRight().getRight()) && ancestor.getLeft().equalsSigned(lastHypo)) {
                        Tree secondAncestor = null;
                        for (Tree second : newTreesFinal) {
                            if (ancestor.getRight().getLeft().equalsSigned(second.getRight()) && second.getLeft().equalsSigned(lastHypo)) {
                                secondAncestor = second;
                                break;
                            }
                        }
                        if (secondAncestor != null) {
                            Tree formAxiom2Tree = new Tree(
                                    secondAncestor,
                                    new Tree(
                                            ancestor,
                                            tree, "", Operations.IMPL
                                    ), "", Operations.IMPL
                            );
                            formAxiom2Tree.getLeft().setParentheses(true);
                            formAxiom2Tree.getRight().getLeft().setParentheses(true);
                            formAxiom2Tree.getRight().getRight().setParentheses(true);
                            newTreesFinal.addLast(formAxiom2Tree);
                            newTreesFinal.addLast(newTreesFinal.getLast().getRight());
                            newTreesFinal.addLast(tree);
                            done = true;
                            break;
                        }
                        done = true;
                    }
                }
                if (!done) {
                    newTreesFinal.addLast(new Tree(lastHypo, new Tree(null, null, "???????", Operations.CONST), "", Operations.IMPL));
                }
            }
        }
        if (hypotheses.length > 1) {
            System.out.print(hypotheses[0]);
        }
        for (i = 1; i < hypotheses.length - 1; i++) {
            System.out.print("," + hypotheses[i]);
        }
        Tree theoremTree = parser.parse(theorem[1]);
        Tree toProve = new Tree (lastHypo, theoremTree, "", Operations.IMPL);
        System.out.print("|- " + toProve + "\n");
        for (Tree tree : newTreesFinal) {
            System.out.println(tree);
        }
    }
}
