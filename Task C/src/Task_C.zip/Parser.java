import java.util.ArrayList;


public class Parser {
    private final ArrayList<String> values = new ArrayList<>();
    private int pos;
    private String string;

    Tree parseExpression() {
        Tree left = parseMul();
        if (string.charAt(pos) == '|') {
            pos++;
            Tree right = parseExpression();
            return new Tree(left, right, "", Operations.OR);
        }
        return left;
    }

    Tree parseMul() {
        Tree left = parseTerm();
        if (string.charAt(pos) == '&') {
            pos++;
            Tree right = parseMul();
            return new Tree(left, right, "", Operations.AND);
        }
        return left;

    }

    Tree parseImpl() {
        Tree left = parseExpression();
        if (string.charAt(pos) == '-') {
            pos += 2;
            Tree right = parseImpl();
            return new Tree(left, right, "", Operations.IMPL);
        }
        return left;
    }


    String parseValue(String str) {
        if (!(String.valueOf(string.charAt(pos)).equals("&") ||
                String.valueOf(string.charAt(pos)).equals("|") ||
                String.valueOf(string.charAt(pos)).equals("-") ||
                String.valueOf(string.charAt(pos)).equals("!") ||
                String.valueOf(string.charAt(pos)).equals(";") ||
                String.valueOf(string.charAt(pos)).equals("(") ||
                String.valueOf(string.charAt(pos)).equals(")"))) {
            String s = String.valueOf(string.charAt(pos));
            pos++;
            return parseValue(str + s);
        } else {
            String value;
            int i = 0;
            try {
                while (!str.equals(values.get(i))) {
                    i++;
                }
                value = values.get(i);
            } catch (IndexOutOfBoundsException e) {
                value = str;
                values.add(value);
            }
            return value;
        }
    }

    Tree parseTerm() {
        int inversions = 0;
        while (string.charAt(pos) == '!') {
            pos++;
            inversions++;
        }
        if (string.charAt(pos) == '(') {
            pos++;
            Tree res = parseImpl();
            if (string.charAt(pos) != ')') {
                System.out.println("???");
            }
            pos++;
            res.setHowManyInversions(inversions + res.getHowManyInversions());
            res.setParentheses(true);
            return res;
        } else {
            if (!(String.valueOf(string.charAt(pos)).equals("&") ||
                    String.valueOf(string.charAt(pos)).equals("|") ||
                    String.valueOf(string.charAt(pos)).equals("-") ||
                    String.valueOf(string.charAt(pos)).equals("!") ||
                    String.valueOf(string.charAt(pos)).equals(";") ||
                    String.valueOf(string.charAt(pos)).equals("(") ||
                    String.valueOf(string.charAt(pos)).equals(")"))) {
                Tree res = new Tree(null, null, parseValue(""), Operations.CONST);
                res.setHowManyInversions(inversions);
                return res;
            } else {
                System.out.println("???");
                Tree res = new Tree(null, null, "", Operations.CONST);
                res.setHowManyInversions(inversions);
                return res;
            }
        }
    }

    Tree parse(String string) {
        this.string = string + ";";
        pos = 0;
        Tree tree = parseImpl();
        tree.normalize();
        tree.setAxiomOrHypothesis(AxiomContainer.isAxiom(tree));
        tree.setParentheses(true);
        return tree;
    }
}
