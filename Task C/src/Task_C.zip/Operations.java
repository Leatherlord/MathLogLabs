public enum Operations {
    OR,
    AND,
    IMPL,
    CONST
}
